<?php
require_once __DIR__ . '/../includes/helpers.php';
session_start_safe();

$id     = (int)($_GET['id'] ?? 0);
$survey = db_fetch('SELECT * FROM surveys WHERE id = ?', [$id]);

if (!$survey) {
    http_response_code(404);
    die('Survey not found.');
}

// Check status & expiry
$open   = survey_is_open($survey);
$reason = '';
if (!$open) {
    if ($survey['status'] === 'draft')  $reason = 'This survey is not yet open.';
    elseif ($survey['status'] === 'closed') $reason = 'This survey has been closed.';
    elseif (survey_is_expired($survey)) $reason = 'This survey has expired.';
    else $reason = 'This survey is currently unavailable.';
}

$questions = db_fetch_all(
    'SELECT * FROM questions WHERE survey_id = ? ORDER BY sort_order, id',
    [$survey['id']]
);
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title><?= h($survey['title']) ?> — FUTMINNA</title>
<link rel="preconnect" href="https://fonts.googleapis.com">
<link href="https://fonts.googleapis.com/css2?family=DM+Serif+Display:ital@0;1&family=Sora:wght@300;400;500;600;700&display=swap" rel="stylesheet">
<link rel="stylesheet" href="<?= APP_URL ?>/assets/css/admin.css">
<style>
body { background: var(--surface); margin: 0; }
</style>
</head>
<body>

<div class="survey-wrap">
  <div class="survey-header">
    <div class="survey-header__logo">◈ FUTMINNA Survey System</div>
    <h1 class="survey-header__title"><?= h($survey['title']) ?></h1>
    <?php if ($survey['description']): ?>
      <p class="survey-header__desc"><?= nl2br(h($survey['description'])) ?></p>
    <?php endif; ?>
    <?php if ($survey['is_anonymous']): ?>
      <p style="margin-top:14px;font-size:.8rem;background:rgba(255,255,255,.12);padding:8px 14px;border-radius:6px;display:inline-block;">
        🔒 Anonymous — your identity will not be collected.
      </p>
    <?php endif; ?>
  </div>

  <div class="survey-body">
    <?php if (!$open): ?>
      <div style="text-align:center;padding:40px;">
        <div style="font-size:3rem;margin-bottom:14px;">🔒</div>
        <h2 style="font-family:var(--font-display);color:var(--green-dk);margin-bottom:8px;">Unavailable</h2>
        <p class="text-muted"><?= h($reason) ?></p>
      </div>
    <?php elseif (empty($questions)): ?>
      <div style="text-align:center;padding:40px;">
        <p class="text-muted">This survey has no questions yet.</p>
      </div>
    <?php else: ?>
      <form id="survey-form" action="<?= APP_URL ?>/public/submit.php" method="POST" novalidate>
        <?= csrf_field() ?>
        <input type="hidden" name="survey_id" value="<?= $survey['id'] ?>">

        <?php if (!$survey['is_anonymous']): ?>
        <div class="form-group">
          <label class="form-label">Full Name *</label>
          <input type="text" name="respondent_name" class="form-control" placeholder="Your full name" required>
        </div>
        <div class="form-group" style="margin-bottom:28px;">
          <label class="form-label">Email Address</label>
          <input type="email" name="respondent_email" class="form-control" placeholder="your.email@example.com">
        </div>
        <?php endif; ?>

        <?php foreach ($questions as $qi => $q):
            $opts = $q['options'] ? json_decode($q['options'], true) : [];
        ?>
        <div class="survey-question">
          <div class="survey-question__label">
            <?= $qi + 1 ?>. <?= h($q['question_text']) ?>
            <?php if ($q['is_required']): ?>
              <span class="survey-question__required">*</span>
            <?php endif; ?>
          </div>

          <?php if ($q['question_type'] === 'mcq'): ?>
            <?php foreach ($opts as $opt): ?>
              <label class="radio-opt">
                <input type="radio" name="answer_<?= $q['id'] ?>" value="<?= h($opt) ?>"
                       <?= $q['is_required'] ? 'required' : '' ?>>
                <?= h($opt) ?>
              </label>
            <?php endforeach; ?>

          <?php elseif ($q['question_type'] === 'rating'): ?>
            <div class="rating-wrap">
              <?php for ($r = 1; $r <= 10; $r++): ?>
                <button type="button" class="rating-btn" data-val="<?= $r ?>"><?= $r ?></button>
              <?php endfor; ?>
            </div>
            <input type="hidden" name="answer_<?= $q['id'] ?>" value=""
                   <?= $q['is_required'] ? 'required' : '' ?>>

          <?php else: /* text */ ?>
            <textarea name="answer_<?= $q['id'] ?>" class="form-control"
                      rows="4" placeholder="Your answer…"
                      <?= $q['is_required'] ? 'required' : '' ?>></textarea>
          <?php endif; ?>
        </div>
        <?php endforeach; ?>

        <div style="margin-top:8px;">
          <button type="submit" class="btn btn--primary" style="width:100%;justify-content:center;padding:14px;font-size:1rem;">
            Submit Response
          </button>
        </div>

        <p style="text-align:center;font-size:.75rem;color:var(--muted);margin-top:16px;">
          Federal University of Technology, Minna &nbsp;·&nbsp; Survey System
          <?php if ($survey['expires_at']): ?>
            &nbsp;·&nbsp; Closes <?= date('d M Y H:i', strtotime($survey['expires_at'])) ?>
          <?php endif; ?>
        </p>
      </form>
    <?php endif; ?>
  </div>
</div>

<script src="<?= APP_URL ?>/assets/js/admin.js"></script>
</body>
</html>

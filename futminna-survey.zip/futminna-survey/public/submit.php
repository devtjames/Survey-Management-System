<?php
require_once __DIR__ . '/../includes/helpers.php';
session_start_safe();
header('Content-Type: application/json');

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    json_response(['error' => 'Method not allowed.'], 405);
}

csrf_protect();

$survey_id = (int)($_POST['survey_id'] ?? 0);
$survey    = db_fetch('SELECT * FROM surveys WHERE id = ?', [$survey_id]);

if (!$survey) json_response(['error' => 'Survey not found.'], 404);
if (!survey_is_open($survey)) json_response(['error' => 'This survey is not currently accepting responses.'], 403);

$questions = db_fetch_all(
    'SELECT * FROM questions WHERE survey_id = ? ORDER BY sort_order, id',
    [$survey_id]
);

if (empty($questions)) json_response(['error' => 'Survey has no questions.'], 400);

// Validate required fields
$errors = [];

$respondent_name  = null;
$respondent_email = null;

if (!$survey['is_anonymous']) {
    $respondent_name = sanitize($_POST['respondent_name'] ?? '');
    $respondent_email = sanitize($_POST['respondent_email'] ?? '');
    if (!$respondent_name) $errors[] = 'Full name is required.';
    if ($respondent_email && !filter_var($respondent_email, FILTER_VALIDATE_EMAIL)) {
        $errors[] = 'Invalid email address.';
    }
}

// Collect and validate answers
$collected = [];
foreach ($questions as $q) {
    $key = 'answer_' . $q['id'];
    $val = isset($_POST[$key]) ? trim($_POST[$key]) : '';

    // Rating comes as a number string
    if ($q['question_type'] === 'rating' && $val !== '') {
        $v = (int)$val;
        if ($v < 1 || $v > 10) {
            $errors[] = 'Rating for "' . $q['question_text'] . '" must be between 1 and 10.';
            continue;
        }
        $val = (string)$v;
    }

    if ($q['is_required'] && $val === '') {
        $errors[] = '"' . mb_substr($q['question_text'], 0, 60) . '" is required.';
    }

    $collected[$q['id']] = $val;
}

if (!empty($errors)) {
    json_response(['error' => implode(' ', $errors)], 422);
}

$ip = $_SERVER['HTTP_X_FORWARDED_FOR'] ?? $_SERVER['REMOTE_ADDR'] ?? null;
if ($ip) $ip = substr(trim(explode(',', $ip)[0]), 0, 45);

get_db()->beginTransaction();
try {
    $session_id = db_insert(
        'INSERT INTO response_sessions (survey_id, respondent_name, respondent_email, ip_address) VALUES (?,?,?,?)',
        [$survey_id, $respondent_name, $respondent_email, $ip]
    );

    foreach ($questions as $q) {
        $val = $collected[$q['id']] ?? '';
        if ($val === '') continue;
        db_query(
            'INSERT INTO answers (session_id, question_id, answer_value) VALUES (?,?,?)',
            [$session_id, $q['id'], $val]
        );
    }

    get_db()->commit();
} catch (Throwable $e) {
    get_db()->rollBack();
    error_log('Survey submit error: ' . $e->getMessage());
    json_response(['error' => 'An error occurred. Please try again.'], 500);
}

json_response([
    'success' => true,
    'message' => 'Thank you! Your response has been recorded successfully.'
]);

<?php
// includes/header.php  — Account layout header
// Expects: $page_title (string), optionally $extra_css (string)
require_once __DIR__ . '/helpers.php';
require_login();
$admin = current_admin();
$css_version = filemtime(__DIR__ . '/../assets/css/admin.css');
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title><?= h($page_title ?? 'Dashboard') ?> — FUTMINNA Surveys</title>
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=DM+Serif+Display:ital@0;1&family=Sora:wght@300;400;500;600;700&display=swap" rel="stylesheet">
<link rel="stylesheet" href="<?= APP_URL ?>/assets/css/admin.css?v=<?= $css_version ?>">
<?= $extra_css ?? '' ?>
</head>
<body>

<nav class="sidebar">
  <div class="sidebar__brand">
    <span class="sidebar__logo">◈</span>
    <div>
      <div class="sidebar__app">FUTMINNA</div>
      <div class="sidebar__sub">Survey System</div>
    </div>
  </div>
  <ul class="sidebar__nav">
    <li><a href="<?= APP_URL ?>/admin/dashboard.php" class="<?= basename($_SERVER['PHP_SELF']) === 'dashboard.php' ? 'active' : '' ?>"><span>⬛</span> Dashboard</a></li>
    <li><a href="<?= APP_URL ?>/admin/surveys.php" class="<?= in_array(basename($_SERVER['PHP_SELF']),['surveys.php','survey_create.php','survey_edit.php']) ? 'active' : '' ?>"><span>📋</span> Surveys</a></li>
    <li><a href="<?= APP_URL ?>/admin/responses.php" class="<?= basename($_SERVER['PHP_SELF']) === 'responses.php' ? 'active' : '' ?>"><span>📊</span> Responses</a></li>
    <li><a href="<?= APP_URL ?>/admin/analytics.php" class="<?= basename($_SERVER['PHP_SELF']) === 'analytics.php' ? 'active' : '' ?>"><span>📈</span> Analytics</a></li>
    <li><a href="<?= APP_URL ?>/admin/export.php" class="<?= basename($_SERVER['PHP_SELF']) === 'export.php' ? 'active' : '' ?>"><span>⬇</span> Export CSV</a></li>
    <li><a href="<?= APP_URL ?>/admin/change_password.php" class="<?= basename($_SERVER['PHP_SELF']) === 'change_password.php' ? 'active' : '' ?>"><span>⚙</span> Change Password</a></li>
  </ul>
  <div class="sidebar__footer">
    <div class="sidebar__admin"><?= h($admin['name']) ?></div>
    <a href="<?= APP_URL ?>/admin/logout.php" class="sidebar__logout">Logout</a>
  </div>
</nav>

<div class="main-wrap">
  <header class="topbar">
    <button class="topbar__toggle" onclick="document.body.classList.toggle('sidebar-open')" aria-label="Toggle menu">☰</button>
    <h1 class="topbar__title"><?= h($page_title ?? 'Dashboard') ?></h1>
    <div class="topbar__meta"><?= date('l, d M Y') ?></div>
  </header>
  <main class="content">
    <?= flash_render() ?>

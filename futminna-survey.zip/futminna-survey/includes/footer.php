  </main><!-- /.content -->
</div><!-- /.main-wrap -->

<script src="<?= APP_URL ?>/assets/js/admin.js"></script>
<?= $extra_js ?? '' ?>
</body>
</html>

<?php
// includes/helpers.php

require_once __DIR__ . '/db.php';

// ─── Session ────────────────────────────────────────────────────────────────
function session_start_safe(): void {
    if (session_status() === PHP_SESSION_NONE) {
        session_set_cookie_params([
            'lifetime' => SESSION_LIFETIME,
            'path'     => '/',
            'secure'   => false,   // set true in production (HTTPS)
            'httponly' => true,
            'samesite' => 'Strict',
        ]);
        session_start();
    }
}

function is_logged_in(): bool {
    session_start_safe();
    return !empty($_SESSION['admin_id']);
}

function require_login(): void {
    if (!is_logged_in()) {
        redirect('/admin/login.php');
    }
}

function current_admin(): ?array {
    if (!is_logged_in()) return null;
    return db_fetch('SELECT * FROM admins WHERE id = ?', [$_SESSION['admin_id']]);
}

function current_user(): ?array {
    return current_admin();
}

// ─── CSRF ────────────────────────────────────────────────────────────────────
function csrf_token(): string {
    session_start_safe();
    if (empty($_SESSION['csrf_token'])) {
        $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
        db_query('INSERT IGNORE INTO csrf_tokens (token) VALUES (?)', [$_SESSION['csrf_token']]);
    }
    return $_SESSION['csrf_token'];
}

function csrf_field(): string {
    return '<input type="hidden" name="csrf_token" value="' . h(csrf_token()) . '">';
}

function verify_csrf(string $token): bool {
    session_start_safe();
    // Clean tokens older than 2 hours
    db_query("DELETE FROM csrf_tokens WHERE created_at < DATE_SUB(NOW(), INTERVAL 2 HOUR)");
    return isset($_SESSION['csrf_token']) && hash_equals($_SESSION['csrf_token'], $token);
}

function csrf_protect(): void {
    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
        $token = $_POST['csrf_token'] ?? ($_SERVER['HTTP_X_CSRF_TOKEN'] ?? '');
        if (!verify_csrf($token)) {
            http_response_code(403);
            die(json_encode(['error' => 'Invalid CSRF token.']));
        }
    }
}

// ─── Output ──────────────────────────────────────────────────────────────────
function h(mixed $val): string {
    return htmlspecialchars((string)$val, ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8');
}

function json_response(array $data, int $code = 200): never {
    http_response_code($code);
    header('Content-Type: application/json');
    echo json_encode($data);
    exit;
}

// ─── Flash messages ──────────────────────────────────────────────────────────
function flash_set(string $type, string $message): void {
    session_start_safe();
    $_SESSION['flash'][] = ['type' => $type, 'msg' => $message];
}

function flash_get(): array {
    session_start_safe();
    $msgs = $_SESSION['flash'] ?? [];
    unset($_SESSION['flash']);
    return $msgs;
}

function flash_render(): string {
    $html = '';
    foreach (flash_get() as $f) {
        $type = h($f['type']);
        $msg  = h($f['msg']);
        $html .= "<div class=\"alert alert--{$type}\">{$msg}</div>";
    }
    return $html;
}

// ─── Input ───────────────────────────────────────────────────────────────────
function sanitize(string $input): string {
    return trim(strip_tags($input));
}

function post(string $key, string $default = ''): string {
    return sanitize($_POST[$key] ?? $default);
}

// ─── Redirect ────────────────────────────────────────────────────────────────
function redirect(string $path): never {
    header('Location: ' . APP_URL . $path);
    exit;
}

// ─── Pagination ──────────────────────────────────────────────────────────────
function paginate(int $total, int $per_page, int $current_page): array {
    $total_pages = max(1, (int) ceil($total / $per_page));
    $current_page = max(1, min($current_page, $total_pages));
    $offset = ($current_page - 1) * $per_page;
    return ['total' => $total, 'per_page' => $per_page, 'current' => $current_page,
            'total_pages' => $total_pages, 'offset' => $offset];
}

// ─── Survey helpers ───────────────────────────────────────────────────────────
function survey_is_expired(array $survey): bool {
    if (empty($survey['expires_at'])) return false;
    return strtotime($survey['expires_at']) < time();
}

function survey_is_open(array $survey): bool {
    return $survey['status'] === 'active' && !survey_is_expired($survey);
}

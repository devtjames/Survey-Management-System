<?php
require_once __DIR__ . '/includes/helpers.php';
redirect('/admin/login.php');

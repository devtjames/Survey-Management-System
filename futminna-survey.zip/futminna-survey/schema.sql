-- FUTMINNA Survey Management System
-- Database Schema
-- Run: mysql -u root -p < schema.sql

CREATE DATABASE IF NOT EXISTS futminna_surveys CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE futminna_surveys;

-- User accounts
CREATE TABLE IF NOT EXISTS admins (
    id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    email VARCHAR(150) NOT NULL UNIQUE,
    password_hash VARCHAR(255) NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB;

-- Surveys are tied to the user account that created them.
CREATE TABLE IF NOT EXISTS surveys (
    id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    admin_id INT UNSIGNED NOT NULL,
    title VARCHAR(255) NOT NULL,
    description TEXT,
    is_anonymous TINYINT(1) NOT NULL DEFAULT 1,
    status ENUM('draft','active','closed') NOT NULL DEFAULT 'draft',
    expires_at DATETIME DEFAULT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (admin_id) REFERENCES admins(id) ON DELETE CASCADE
) ENGINE=InnoDB;

-- Questions
CREATE TABLE IF NOT EXISTS questions (
    id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    survey_id INT UNSIGNED NOT NULL,
    question_text TEXT NOT NULL,
    question_type ENUM('mcq','text','rating') NOT NULL DEFAULT 'text',
    options JSON DEFAULT NULL,        -- for MCQ only
    is_required TINYINT(1) NOT NULL DEFAULT 1,
    sort_order INT UNSIGNED NOT NULL DEFAULT 0,
    FOREIGN KEY (survey_id) REFERENCES surveys(id) ON DELETE CASCADE
) ENGINE=InnoDB;

-- Response sessions (one per survey submission)
CREATE TABLE IF NOT EXISTS response_sessions (
    id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    survey_id INT UNSIGNED NOT NULL,
    respondent_name VARCHAR(100) DEFAULT NULL,
    respondent_email VARCHAR(150) DEFAULT NULL,
    ip_address VARCHAR(45) DEFAULT NULL,
    submitted_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (survey_id) REFERENCES surveys(id) ON DELETE CASCADE
) ENGINE=InnoDB;

-- Individual answers
CREATE TABLE IF NOT EXISTS answers (
    id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    session_id INT UNSIGNED NOT NULL,
    question_id INT UNSIGNED NOT NULL,
    answer_value TEXT NOT NULL,
    FOREIGN KEY (session_id) REFERENCES response_sessions(id) ON DELETE CASCADE,
    FOREIGN KEY (question_id) REFERENCES questions(id) ON DELETE CASCADE
) ENGINE=InnoDB;

-- CSRF tokens
CREATE TABLE IF NOT EXISTS csrf_tokens (
    token CHAR(64) NOT NULL PRIMARY KEY,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_created (created_at)
) ENGINE=InnoDB;

-- Seed default starter account: admin@futminna.edu.ng / password
INSERT INTO admins (name, email, password_hash) VALUES (
    'System Administrator',
    'admin@futminna.edu.ng',
    '$2y$10$2dVIedSJUF.N/3VRep.Ncum.OYvy2lfTvnyLojGf8.Hr.e66GVk1K'
) ON DUPLICATE KEY UPDATE id=id;
-- Note: password above is 'password' — change via UI on first login.
-- To generate your own: php -r "echo password_hash('YourPassword', PASSWORD_BCRYPT, ['cost'=>12]);"

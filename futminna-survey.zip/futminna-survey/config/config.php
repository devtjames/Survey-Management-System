<?php
// config/config.php — Central configuration

define('DB_HOST', 'localhost');
define('DB_NAME', 'futminna_surveys');
define('DB_USER', 'root');
define('DB_PASS', '');
define('DB_CHARSET', 'utf8mb4');

define('APP_NAME', 'FUTMINNA Survey System');
define('APP_URL',  'http://localhost/futminna-survey');
define('SESSION_LIFETIME', 3600); // 1 hour

// Error display (set false in production)
define('DEBUG_MODE', true);

if (DEBUG_MODE) {
    ini_set('display_errors', 1);
    error_reporting(E_ALL);
} else {
    ini_set('display_errors', 0);
    error_reporting(0);
}

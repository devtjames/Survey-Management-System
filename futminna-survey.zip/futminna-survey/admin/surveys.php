<?php
require_once __DIR__ . '/../includes/helpers.php';
require_login();
$page_title = 'Surveys';

$status_filter = sanitize($_GET['status'] ?? '');
$search        = sanitize($_GET['q'] ?? '');
$per_page      = 15;
$page          = max(1, (int)($_GET['page'] ?? 1));

$where  = ['s.admin_id = ?'];
$params = [$_SESSION['admin_id']];

if ($status_filter && in_array($status_filter, ['active','draft','closed'])) {
    $where[]  = 's.status = ?';
    $params[] = $status_filter;
}
if ($search) {
    $where[]  = 's.title LIKE ?';
    $params[] = "%{$search}%";
}

$where_sql = 'WHERE ' . implode(' AND ', $where);

$total = (int) db_fetch(
    "SELECT COUNT(*) AS c FROM surveys s {$where_sql}",
    $params
)['c'];

$pager   = paginate($total, $per_page, $page);
$surveys = db_fetch_all(
    "SELECT s.*,
            (SELECT COUNT(*) FROM response_sessions r WHERE r.survey_id = s.id) AS resp_count
     FROM surveys s {$where_sql}
     ORDER BY s.created_at DESC
     LIMIT {$per_page} OFFSET {$pager['offset']}",
    $params
);

include __DIR__ . '/../includes/header.php';
?>

<input type="hidden" id="csrf_token" value="<?= h(csrf_token()) ?>">

<div class="page-actions">
  <h2>All Surveys</h2>
  <a href="<?= APP_URL ?>/admin/survey_create.php" class="btn btn--primary">+ New Survey</a>
</div>

<div class="filter-bar">
  <form method="GET" style="display:flex;gap:10px;flex-wrap:wrap;">
    <input type="text" name="q" value="<?= h($search) ?>" placeholder="Search surveys…" class="form-control" style="width:220px;">
    <select name="status">
      <option value="">All Statuses</option>
      <?php foreach (['active','draft','closed'] as $st): ?>
        <option value="<?= $st ?>" <?= $status_filter === $st ? 'selected' : '' ?>><?= ucfirst($st) ?></option>
      <?php endforeach; ?>
    </select>
    <button type="submit" class="btn btn--outline btn--sm">Filter</button>
    <?php if ($search || $status_filter): ?>
      <a href="surveys.php" class="btn btn--outline btn--sm">Clear</a>
    <?php endif; ?>
  </form>
</div>

<div class="card" style="padding:0;overflow:hidden;">
  <?php if (empty($surveys)): ?>
    <p class="text-muted text-center" style="padding:40px;">No surveys found.</p>
  <?php else: ?>
    <div class="table-wrap table-wrap--surveys">
      <table class="responsive-table responsive-table--surveys">
        <thead>
          <tr>
            <th>#</th>
            <th>Title</th>
            <th>Status</th>
            <th>Type</th>
            <th>Questions</th>
            <th>Responses</th>
            <th>Expires</th>
            <th>Created</th>
            <th>Actions</th>
          </tr>
        </thead>
        <tbody>
        <?php foreach ($surveys as $s):
            $qcount  = db_fetch('SELECT COUNT(*) AS c FROM questions WHERE survey_id = ?', [$s['id']])['c'];
            $expired = survey_is_expired($s);
        ?>
          <tr id="survey-row-<?= $s['id'] ?>">
            <td class="text-muted" style="font-size:.8rem;"><?= $s['id'] ?></td>
            <td>
              <strong><?= h($s['title']) ?></strong><br>
              <span class="text-muted" style="font-size:.78rem;"><?= h(mb_strimwidth($s['description'] ?? '', 0, 60, '…')) ?></span>
            </td>
            <td>
              <select data-status-survey="<?= $s['id'] ?>" class="form-control" style="padding:4px 8px;font-size:.8rem;width:auto;">
                <?php foreach (['draft','active','closed'] as $st): ?>
                  <option value="<?= $st ?>" <?= $s['status'] === $st ? 'selected' : '' ?>><?= ucfirst($st) ?></option>
                <?php endforeach; ?>
              </select>
              <?php if ($expired): ?>
                <span class="badge badge--expired" style="margin-top:3px;display:inline-block;">Expired</span>
              <?php endif; ?>
            </td>
            <td>
              <span class="badge <?= $s['is_anonymous'] ? 'badge--anon' : '' ?>">
                <?= $s['is_anonymous'] ? 'Anonymous' : 'Identified' ?>
              </span>
            </td>
            <td><?= $qcount ?></td>
            <td><?= $s['resp_count'] ?></td>
            <td><?= $s['expires_at'] ? date('d M Y', strtotime($s['expires_at'])) : '—' ?></td>
            <td><?= date('d M Y', strtotime($s['created_at'])) ?></td>
            <td>
              <div class="flex gap-8" style="flex-wrap:wrap;">
                <a href="<?= APP_URL ?>/admin/survey_edit.php?id=<?= $s['id'] ?>" class="btn btn--outline btn--xs">Edit</a>
                <a href="<?= APP_URL ?>/admin/analytics.php?survey_id=<?= $s['id'] ?>" class="btn btn--outline btn--xs">Analytics</a>
                <button
                  data-copy-link="<?= APP_URL ?>/public/survey.php?id=<?= $s['id'] ?>"
                  class="btn btn--outline btn--xs copy-link" title="Copy public link">🔗 Link</button>
                <button data-delete-survey="<?= $s['id'] ?>" class="btn btn--danger btn--xs">Delete</button>
              </div>
            </td>
          </tr>
        <?php endforeach; ?>
        </tbody>
      </table>
    </div>

    <!-- Pagination -->
    <?php if ($pager['total_pages'] > 1): ?>
    <div style="display:flex;justify-content:center;gap:6px;padding:18px;">
      <?php for ($p = 1; $p <= $pager['total_pages']; $p++):
          $q = http_build_query(['q' => $search, 'status' => $status_filter, 'page' => $p]);
      ?>
        <a href="?<?= $q ?>" class="btn btn--outline btn--sm <?= $p === $pager['current'] ? 'btn--primary' : '' ?>"><?= $p ?></a>
      <?php endfor; ?>
    </div>
    <?php endif; ?>
  <?php endif; ?>
</div>

<?php include __DIR__ . '/../includes/footer.php'; ?>

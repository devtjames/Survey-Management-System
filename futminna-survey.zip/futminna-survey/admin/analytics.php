<?php
require_once __DIR__ . '/../includes/helpers.php';
require_login();

$admin_surveys = db_fetch_all(
    'SELECT id, title FROM surveys WHERE admin_id = ? ORDER BY title',
    [$_SESSION['admin_id']]
);

$survey_id = (int)($_GET['survey_id'] ?? 0);
$survey    = null;
$questions = [];

if ($survey_id) {
    $survey = db_fetch('SELECT * FROM surveys WHERE id = ? AND admin_id = ?', [$survey_id, $_SESSION['admin_id']]);
    if (!$survey) { flash_set('error', 'Survey not found.'); redirect('/admin/analytics.php'); }
    $questions = db_fetch_all('SELECT * FROM questions WHERE survey_id = ? ORDER BY sort_order, id', [$survey_id]);
}

$page_title  = $survey ? 'Analytics: ' . $survey['title'] : 'Analytics';
$chart_data  = [];

if ($survey && !empty($questions)) {
    foreach ($questions as $q) {
        $qd = ['id' => $q['id'], 'text' => $q['question_text'], 'type' => $q['question_type']];

        if ($q['question_type'] === 'mcq') {
            $opts     = json_decode($q['options'] ?? '[]', true);
            $counts   = [];
            $answers  = db_fetch_all(
                'SELECT answer_value, COUNT(*) AS cnt FROM answers WHERE question_id = ? GROUP BY answer_value',
                [$q['id']]
            );
            $map = [];
            foreach ($answers as $a) $map[$a['answer_value']] = (int)$a['cnt'];
            foreach ($opts as $opt) $counts[$opt] = $map[$opt] ?? 0;
            $qd['labels'] = array_keys($counts);
            $qd['values'] = array_values($counts);

        } elseif ($q['question_type'] === 'rating') {
            $dist = array_fill(1, 10, 0);
            $all  = db_fetch_all('SELECT answer_value FROM answers WHERE question_id = ?', [$q['id']]);
            foreach ($all as $a) {
                $v = (int)$a['answer_value'];
                if ($v >= 1 && $v <= 10) $dist[$v]++;
            }
            $total_r = array_sum($dist);
            $avg     = $total_r > 0 ? round(array_sum(array_map(fn($k,$v)=>$k*$v, array_keys($dist), $dist)) / $total_r, 2) : 0;
            $qd['dist']  = $dist;
            $qd['avg']   = $avg;
            $qd['total'] = $total_r;

        } else {
            $qd['sample'] = db_fetch_all(
                'SELECT answer_value FROM answers WHERE question_id = ? ORDER BY id DESC LIMIT 10',
                [$q['id']]
            );
            $qd['count'] = (int)db_fetch('SELECT COUNT(*) AS c FROM answers WHERE question_id = ?', [$q['id']])['c'];
        }

        $chart_data[] = $qd;
    }
}

$total_responses = $survey ? (int)db_fetch('SELECT COUNT(*) AS c FROM response_sessions WHERE survey_id = ?', [$survey_id])['c'] : 0;

$extra_js = '<script src="https://cdn.jsdelivr.net/npm/chart.js@4/dist/chart.umd.min.js"></script>';
include __DIR__ . '/../includes/header.php';
?>

<div class="page-actions">
  <h2>Analytics<?= $survey ? ': ' . h($survey['title']) : '' ?></h2>
  <?php if ($survey_id): ?>
    <a href="<?= APP_URL ?>/admin/export.php?survey_id=<?= $survey_id ?>" class="btn btn--gold btn--sm">⬇ Export CSV</a>
    <a href="<?= APP_URL ?>/admin/responses.php?survey_id=<?= $survey_id ?>" class="btn btn--outline btn--sm">View Raw Responses</a>
  <?php endif; ?>
</div>

<div class="filter-bar">
  <form method="GET">
    <select name="survey_id" onchange="this.form.submit()" class="form-control">
      <option value="">— Select a Survey —</option>
      <?php foreach ($admin_surveys as $sv): ?>
        <option value="<?= $sv['id'] ?>" <?= $survey_id === (int)$sv['id'] ? 'selected' : '' ?>>
          <?= h($sv['title']) ?>
        </option>
      <?php endforeach; ?>
    </select>
  </form>
</div>

<?php if (!$survey): ?>
  <div class="card text-center" style="padding:48px;">
    <p class="text-muted">Select a survey to view analytics.</p>
  </div>
<?php elseif ($total_responses === 0): ?>
  <div class="card text-center" style="padding:48px;">
    <p class="text-muted">No responses collected yet for this survey.</p>
  </div>
<?php else: ?>

  <div class="stats-grid" style="margin-bottom:22px;">
    <div class="stat-card">
      <div class="stat-card__label">Total Responses</div>
      <div class="stat-card__value"><?= number_format($total_responses) ?></div>
    </div>
    <div class="stat-card stat-card--gold">
      <div class="stat-card__label">Questions</div>
      <div class="stat-card__value"><?= count($questions) ?></div>
    </div>
    <div class="stat-card stat-card--blue">
      <div class="stat-card__label">Survey Type</div>
      <div class="stat-card__value" style="font-size:1.1rem;margin-top:4px;">
        <?= $survey['is_anonymous'] ? 'Anonymous' : 'Identified' ?>
      </div>
    </div>
    <div class="stat-card stat-card--red">
      <div class="stat-card__label">Status</div>
      <div class="stat-card__value" style="font-size:1.1rem;margin-top:4px;"><?= ucfirst($survey['status']) ?></div>
    </div>
  </div>

  <?php foreach ($chart_data as $ci => $qd): ?>
  <div class="card">
    <div class="card__title" style="margin-bottom:18px;">
      Q<?= $ci+1 ?>. <?= h($qd['text']) ?>
      <span class="badge badge--<?= $qd['type'] === 'mcq' ? 'active' : ($qd['type'] === 'rating' ? 'draft' : 'closed') ?>" style="margin-left:8px;font-size:.65rem;">
        <?= strtoupper($qd['type']) ?>
      </span>
    </div>

    <?php if ($qd['type'] === 'mcq'): ?>
      <div style="display:grid;grid-template-columns:1fr 1fr;gap:22px;align-items:center;">
        <div>
          <canvas id="chart-mcq-<?= $qd['id'] ?>" style="max-height:220px;"></canvas>
        </div>
        <div>
          <?php
          $total_q = array_sum($qd['values']);
          foreach ($qd['labels'] as $li => $label):
              $val = $qd['values'][$li];
              $pct = $total_q > 0 ? round($val / $total_q * 100) : 0;
          ?>
            <div style="margin-bottom:10px;">
              <div style="display:flex;justify-content:space-between;font-size:.83rem;margin-bottom:4px;">
                <span><?= h($label) ?></span>
                <span class="text-muted"><?= $val ?> (<?= $pct ?>%)</span>
              </div>
              <div class="rating-bar"><div class="rating-bar__fill" style="width:<?= $pct ?>%;"></div></div>
            </div>
          <?php endforeach; ?>
        </div>
      </div>
      <script>
      document.addEventListener('DOMContentLoaded', () => initAnalyticsChart(
        'chart-mcq-<?= $qd['id'] ?>',
        'pie',
        <?= json_encode($qd['labels']) ?>,
        [{ data: <?= json_encode($qd['values']) ?> }]
      ));
      </script>

    <?php elseif ($qd['type'] === 'rating'): ?>
      <div style="margin-bottom:12px;">
        <strong style="font-size:1.4rem;color:var(--green);"><?= $qd['avg'] ?></strong>
        <span class="text-muted"> / 10 average &nbsp;|&nbsp; <?= $qd['total'] ?> responses</span>
      </div>
      <div>
        <?php foreach (range(10, 1, -1) as $rv):
            $cnt = $qd['dist'][$rv] ?? 0;
            $pct = $qd['total'] > 0 ? round($cnt / $qd['total'] * 100) : 0;
        ?>
          <div class="rating-bar-wrap">
            <div class="label"><?= $rv ?></div>
            <div class="rating-bar"><div class="rating-bar__fill" style="width:<?= $pct ?>%;"></div></div>
            <div class="pct"><?= $pct ?>%</div>
            <div style="font-size:.78rem;color:var(--muted);width:30px;"><?= $cnt ?></div>
          </div>
        <?php endforeach; ?>
      </div>

    <?php else: /* text */ ?>
      <p class="text-muted" style="font-size:.85rem;margin-bottom:12px;"><?= $qd['count'] ?> text responses. Showing latest 10:</p>
      <?php foreach ($qd['sample'] as $ans): ?>
        <div style="background:var(--surface);border-left:3px solid var(--green);padding:10px 14px;border-radius:0 var(--radius) var(--radius) 0;margin-bottom:8px;font-size:.88rem;">
          <?= h($ans['answer_value']) ?>
        </div>
      <?php endforeach; ?>
    <?php endif; ?>
  </div>
  <?php endforeach; ?>

<?php endif; ?>

<?php include __DIR__ . '/../includes/footer.php'; ?>

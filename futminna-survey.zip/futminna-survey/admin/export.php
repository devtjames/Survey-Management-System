<?php
require_once __DIR__ . '/../includes/helpers.php';
require_login();

$survey_id = (int)($_GET['survey_id'] ?? 0);

// If no GET param, show selection UI
if (!$survey_id) {
    $page_title    = 'Export CSV';
    $admin_surveys = db_fetch_all(
        'SELECT id, title, status FROM surveys WHERE admin_id = ? ORDER BY title',
        [$_SESSION['admin_id']]
    );
    include __DIR__ . '/../includes/header.php';
    ?>
    <div class="page-actions"><h2>Export Data</h2></div>
    <div class="card">
      <div class="card__title">Select Survey to Export</div>
      <?php if (empty($admin_surveys)): ?>
        <p class="text-muted">No surveys found.</p>
      <?php else: ?>
        <div class="table-wrap table-wrap--export">
          <table class="responsive-table responsive-table--export">
            <thead><tr><th>Title</th><th>Status</th><th></th></tr></thead>
            <tbody>
            <?php foreach ($admin_surveys as $s): ?>
              <tr>
                <td><?= h($s['title']) ?></td>
                <td><span class="badge badge--<?= h($s['status']) ?>"><?= h($s['status']) ?></span></td>
                <td><a href="export.php?survey_id=<?= $s['id'] ?>" class="btn btn--gold btn--sm">⬇ Download CSV</a></td>
              </tr>
            <?php endforeach; ?>
            </tbody>
          </table>
        </div>
      <?php endif; ?>
    </div>
    <?php
    include __DIR__ . '/../includes/footer.php';
    exit;
}

// Validate ownership
$survey = db_fetch('SELECT * FROM surveys WHERE id = ? AND admin_id = ?', [$survey_id, $_SESSION['admin_id']]);
if (!$survey) { flash_set('error', 'Survey not found.'); redirect('/admin/export.php'); }

$questions = db_fetch_all(
    'SELECT * FROM questions WHERE survey_id = ? ORDER BY sort_order, id', [$survey_id]
);
$sessions = db_fetch_all(
    'SELECT * FROM response_sessions WHERE survey_id = ? ORDER BY submitted_at', [$survey_id]
);

// Stream CSV
$filename = 'survey_' . $survey_id . '_' . date('Ymd_His') . '.csv';
header('Content-Type: text/csv; charset=UTF-8');
header("Content-Disposition: attachment; filename=\"{$filename}\"");
header('Cache-Control: no-cache, no-store');
header('Pragma: no-cache');

$out = fopen('php://output', 'w');
// BOM for Excel UTF-8
fwrite($out, "\xEF\xBB\xBF");

// Header row
$headers = ['Session ID', 'Submitted At', 'IP Address'];
if (!$survey['is_anonymous']) {
    array_push($headers, 'Respondent Name', 'Respondent Email');
}
foreach ($questions as $q) {
    $headers[] = $q['question_text'];
}
fputcsv($out, $headers);

// Data rows
foreach ($sessions as $session) {
    $answers = db_fetch_all(
        'SELECT a.answer_value, a.question_id FROM answers a WHERE a.session_id = ?',
        [$session['id']]
    );
    $ans_map = [];
    foreach ($answers as $a) $ans_map[$a['question_id']] = $a['answer_value'];

    $row = [$session['id'], $session['submitted_at'], $session['ip_address']];
    if (!$survey['is_anonymous']) {
        $row[] = $session['respondent_name'] ?? '';
        $row[] = $session['respondent_email'] ?? '';
    }
    foreach ($questions as $q) {
        $row[] = $ans_map[$q['id']] ?? '';
    }
    fputcsv($out, $row);
}

fclose($out);
exit;

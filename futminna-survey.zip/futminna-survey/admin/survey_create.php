<?php
require_once __DIR__ . '/../includes/helpers.php';
require_login();
$page_title = 'Create Survey';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrf_protect();

    $title       = post('title');
    $description = post('description');
    $is_anon     = isset($_POST['is_anonymous']) ? 1 : 0;
    $status      = in_array(post('status'), ['draft','active','closed']) ? post('status') : 'draft';
    $expires_raw = post('expires_at');
    $expires_at  = $expires_raw ? date('Y-m-d H:i:s', strtotime($expires_raw)) : null;

    if (!$title) {
        flash_set('error', 'Survey title is required.');
        redirect('/admin/survey_create.php');
    }

    $survey_id = db_insert(
        'INSERT INTO surveys (admin_id, title, description, is_anonymous, status, expires_at) VALUES (?,?,?,?,?,?)',
        [$_SESSION['admin_id'], $title, $description, $is_anon, $status, $expires_at]
    );

    // Save questions
    $q_texts    = $_POST['q_text']    ?? [];
    $q_types    = $_POST['q_type']    ?? [];
    $q_required = $_POST['q_required'] ?? [];
    $q_options  = $_POST['q_options']  ?? [];

    foreach ($q_texts as $i => $qtext) {
        $qtext = sanitize($qtext);
        $qtype = $q_types[$i] ?? 'text';
        if (!in_array($qtype, ['mcq','text','rating'])) $qtype = 'text';
        if (!$qtext) continue;

        $required = ($q_required[$i] ?? '0') === '1' ? 1 : 0;

        $opts_json = null;
        if ($qtype === 'mcq' && isset($q_options[$i + 1])) {
            $opts = array_filter(array_map('trim', $q_options[$i + 1]));
            if (!empty($opts)) $opts_json = json_encode(array_values($opts));
        }

        db_query(
            'INSERT INTO questions (survey_id, question_text, question_type, options, is_required, sort_order) VALUES (?,?,?,?,?,?)',
            [$survey_id, $qtext, $qtype, $opts_json, $required, $i]
        );
    }

    flash_set('success', 'Survey created successfully!');
    redirect('/admin/surveys.php');
}

include __DIR__ . '/../includes/header.php';
?>

<div class="page-actions">
  <h2>Create New Survey</h2>
  <a href="<?= APP_URL ?>/admin/surveys.php" class="btn btn--outline">← Back</a>
</div>

<form method="POST" action="">
  <?= csrf_field() ?>

  <div class="card">
    <div class="card__title">Survey Details</div>
    <div class="form-group">
      <label class="form-label">Title *</label>
      <input type="text" name="title" class="form-control" placeholder="e.g. Student Satisfaction Survey 2025" required>
    </div>
    <div class="form-group">
      <label class="form-label">Description</label>
      <textarea name="description" class="form-control" placeholder="Briefly describe the purpose of this survey…" rows="3"></textarea>
    </div>
    <div class="form-row">
      <div class="form-group">
        <label class="form-label">Status</label>
        <select name="status" class="form-control">
          <option value="draft">Draft</option>
          <option value="active">Active (Live)</option>
          <option value="closed">Closed</option>
        </select>
      </div>
      <div class="form-group">
        <label class="form-label">Expiration Date &amp; Time</label>
        <input type="datetime-local" name="expires_at" class="form-control">
        <span class="form-hint">Leave blank for no expiration.</span>
      </div>
    </div>
    <div class="form-group">
      <label style="display:flex;align-items:center;gap:8px;cursor:pointer;font-size:.88rem;font-weight:600;color:var(--muted);">
        <input type="checkbox" name="is_anonymous" value="1" checked style="width:16px;height:16px;accent-color:var(--green);">
        Anonymous Responses (do not collect name/email)
      </label>
    </div>
  </div>

  <div class="card">
    <div class="card__title">Questions</div>

    <div id="question-builder" data-start-count="0">
      <!-- questions injected here by JS -->
    </div>

    <div style="display:flex;gap:10px;flex-wrap:wrap;padding-top:8px;border-top:1px dashed var(--border);margin-top:4px;">
      <button type="button" id="add-mcq" class="btn btn--outline btn--sm">+ Multiple Choice</button>
      <button type="button" id="add-text" class="btn btn--outline btn--sm">+ Text Answer</button>
      <button type="button" id="add-rating" class="btn btn--outline btn--sm">+ Rating (1–10)</button>
    </div>
  </div>

  <div style="display:flex;gap:10px;justify-content:flex-end;">
    <a href="<?= APP_URL ?>/admin/surveys.php" class="btn btn--outline">Cancel</a>
    <button type="submit" class="btn btn--primary">💾 Save Survey</button>
  </div>
</form>

<?php include __DIR__ . '/../includes/footer.php'; ?>

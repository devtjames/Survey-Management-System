<?php
require_once __DIR__ . '/../../includes/helpers.php';
session_start_safe();
if (!is_logged_in()) json_response(['error' => 'Unauthorized'], 401);
csrf_protect();

$id     = (int)($_POST['id'] ?? 0);
$survey = db_fetch('SELECT id FROM surveys WHERE id = ? AND admin_id = ?', [$id, $_SESSION['admin_id']]);
if (!$survey) json_response(['error' => 'Not found'], 404);

db_query('DELETE FROM surveys WHERE id = ? AND admin_id = ?', [$id, $_SESSION['admin_id']]);
json_response(['success' => true]);

<?php
require_once __DIR__ . '/../includes/helpers.php';
session_start_safe();
$_SESSION = [];
session_destroy();
redirect('/admin/login.php');

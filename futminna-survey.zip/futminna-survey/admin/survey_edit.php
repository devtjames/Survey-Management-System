<?php
require_once __DIR__ . '/../includes/helpers.php';
require_login();

$id     = (int)($_GET['id'] ?? 0);
$survey = db_fetch('SELECT * FROM surveys WHERE id = ? AND admin_id = ?', [$id, $_SESSION['admin_id']]);
if (!$survey) { flash_set('error', 'Survey not found.'); redirect('/admin/surveys.php'); }

$questions = db_fetch_all('SELECT * FROM questions WHERE survey_id = ? ORDER BY sort_order, id', [$id]);
$page_title = 'Edit: ' . $survey['title'];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrf_protect();

    $title       = post('title');
    $description = post('description');
    $is_anon     = isset($_POST['is_anonymous']) ? 1 : 0;
    $status      = in_array(post('status'), ['draft','active','closed']) ? post('status') : 'draft';
    $expires_raw = post('expires_at');
    $expires_at  = $expires_raw ? date('Y-m-d H:i:s', strtotime($expires_raw)) : null;

    if (!$title) { flash_set('error', 'Title required.'); redirect("/admin/survey_edit.php?id={$id}"); }

    db_query(
        'UPDATE surveys SET title=?, description=?, is_anonymous=?, status=?, expires_at=?, updated_at=NOW() WHERE id=? AND admin_id=?',
        [$title, $description, $is_anon, $status, $expires_at, $id, $_SESSION['admin_id']]
    );

    // Replace questions
    db_query('DELETE FROM questions WHERE survey_id = ?', [$id]);

    $q_texts    = $_POST['q_text']    ?? [];
    $q_types    = $_POST['q_type']    ?? [];
    $q_required = $_POST['q_required'] ?? [];
    $q_options  = $_POST['q_options']  ?? [];

    foreach ($q_texts as $i => $qtext) {
        $qtext = sanitize($qtext);
        $qtype = $q_types[$i] ?? 'text';
        if (!in_array($qtype, ['mcq','text','rating'])) $qtype = 'text';
        if (!$qtext) continue;
        $required  = ($q_required[$i] ?? '0') === '1' ? 1 : 0;
        $opts_json = null;
        if ($qtype === 'mcq' && isset($q_options[$i + 1])) {
            $opts = array_filter(array_map('trim', $q_options[$i + 1]));
            if (!empty($opts)) $opts_json = json_encode(array_values($opts));
        }
        db_query(
            'INSERT INTO questions (survey_id, question_text, question_type, options, is_required, sort_order) VALUES (?,?,?,?,?,?)',
            [$id, $qtext, $qtype, $opts_json, $required, $i]
        );
    }

    flash_set('success', 'Survey updated.');
    redirect("/admin/survey_edit.php?id={$id}");
}

include __DIR__ . '/../includes/header.php';
?>

<div class="page-actions">
  <h2>Edit Survey</h2>
  <div style="display:flex;gap:8px;">
    <a href="<?= APP_URL ?>/public/survey.php?id=<?= $id ?>" target="_blank" class="btn btn--outline btn--sm">🔗 Preview</a>
    <a href="<?= APP_URL ?>/admin/analytics.php?survey_id=<?= $id ?>" class="btn btn--outline btn--sm">📊 Analytics</a>
    <a href="<?= APP_URL ?>/admin/surveys.php" class="btn btn--outline btn--sm">← Back</a>
  </div>
</div>

<form method="POST" action="">
  <?= csrf_field() ?>

  <div class="card">
    <div class="card__title">Survey Details</div>
    <div class="form-group">
      <label class="form-label">Title *</label>
      <input type="text" name="title" class="form-control" value="<?= h($survey['title']) ?>" required>
    </div>
    <div class="form-group">
      <label class="form-label">Description</label>
      <textarea name="description" class="form-control" rows="3"><?= h($survey['description']) ?></textarea>
    </div>
    <div class="form-row">
      <div class="form-group">
        <label class="form-label">Status</label>
        <select name="status" class="form-control">
          <?php foreach (['draft','active','closed'] as $st): ?>
            <option value="<?= $st ?>" <?= $survey['status'] === $st ? 'selected' : '' ?>><?= ucfirst($st) ?></option>
          <?php endforeach; ?>
        </select>
      </div>
      <div class="form-group">
        <label class="form-label">Expiration Date &amp; Time</label>
        <input type="datetime-local" name="expires_at" class="form-control"
               value="<?= $survey['expires_at'] ? date('Y-m-d\TH:i', strtotime($survey['expires_at'])) : '' ?>">
      </div>
    </div>
    <div class="form-group">
      <label style="display:flex;align-items:center;gap:8px;cursor:pointer;font-size:.88rem;font-weight:600;color:var(--muted);">
        <input type="checkbox" name="is_anonymous" value="1"
               <?= $survey['is_anonymous'] ? 'checked' : '' ?>
               style="width:16px;height:16px;accent-color:var(--green);">
        Anonymous Responses
      </label>
    </div>
  </div>

  <div class="card">
    <div class="card__title">Questions</div>

    <div id="question-builder" data-start-count="<?= count($questions) ?>">
      <?php foreach ($questions as $qi => $q):
          $opts = $q['options'] ? json_decode($q['options'], true) : [];
          $n    = $qi + 1;
      ?>
      <div class="question-item">
        <button type="button" class="remove-btn" onclick="this.closest('.question-item').remove();renumber();">✕</button>
        <div class="question-item__header">
          <div class="question-item__num"><?= $n ?></div>
          <input type="hidden" name="q_type[]" value="<?= h($q['question_type']) ?>">
          <span class="q-type-label"><?= strtoupper($q['question_type']) ?></span>
        </div>
        <div class="form-group mb-0">
          <input type="text" name="q_text[]" class="form-control"
                 value="<?= h($q['question_text']) ?>" placeholder="Question text…" required>
        </div>
        <div class="form-row mt-1" style="grid-template-columns:auto 1fr;align-items:center;margin-top:8px;">
          <label style="display:flex;align-items:center;gap:6px;font-size:.8rem;color:var(--muted);">
            <input type="checkbox" name="q_required_<?= $n ?>" value="1" <?= $q['is_required'] ? 'checked' : '' ?>> Required
          </label>
          <input type="hidden" name="q_required[]" value="<?= $q['is_required'] ? '1' : '0' ?>" class="required-hidden-<?= $n ?>">
        </div>
        <?php if ($q['question_type'] === 'mcq'): ?>
        <div class="mcq-options" id="mcq-opts-<?= $n ?>">
          <div class="form-hint mb-0" style="margin:8px 0 6px;">Options:</div>
          <?php foreach ($opts as $oi => $opt): ?>
          <div class="mcq-option">
            <input type="text" name="q_options[<?= $n ?>][]" class="form-control" value="<?= h($opt) ?>">
            <?php if ($oi === 0): ?>
              <button type="button" class="btn btn--outline btn--xs" onclick="addMcqOpt(<?= $n ?>)">+ Add</button>
            <?php else: ?>
              <button type="button" class="btn btn--danger btn--xs" onclick="this.closest('.mcq-option').remove()">✕</button>
            <?php endif; ?>
          </div>
          <?php endforeach; ?>
          <?php if (empty($opts)): ?>
          <div class="mcq-option">
            <input type="text" name="q_options[<?= $n ?>][]" class="form-control" placeholder="Option 1" required>
            <button type="button" class="btn btn--outline btn--xs" onclick="addMcqOpt(<?= $n ?>)">+ Add</button>
          </div>
          <?php endif; ?>
        </div>
        <?php elseif ($q['question_type'] === 'rating'): ?>
          <p class="form-hint mt-1">Respondents will rate 1–10.</p>
        <?php endif; ?>
      </div>
      <?php endforeach; ?>
    </div>

    <div style="display:flex;gap:10px;flex-wrap:wrap;padding-top:8px;border-top:1px dashed var(--border);margin-top:4px;">
      <button type="button" id="add-mcq"    class="btn btn--outline btn--sm">+ Multiple Choice</button>
      <button type="button" id="add-text"   class="btn btn--outline btn--sm">+ Text Answer</button>
      <button type="button" id="add-rating" class="btn btn--outline btn--sm">+ Rating (1–10)</button>
    </div>
  </div>

  <div style="display:flex;gap:10px;justify-content:flex-end;">
    <a href="<?= APP_URL ?>/admin/surveys.php" class="btn btn--outline">Cancel</a>
    <button type="submit" class="btn btn--primary">💾 Save Changes</button>
  </div>
</form>

<?php include __DIR__ . '/../includes/footer.php'; ?>

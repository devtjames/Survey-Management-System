<?php
require_once __DIR__ . '/../includes/helpers.php';
require_login();

$page_title = 'Change Password';
$user = current_user();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrf_protect();

    $current_password = $_POST['current_password'] ?? '';
    $new_password     = $_POST['new_password'] ?? '';
    $confirm_password = $_POST['confirm_password'] ?? '';

    if (!$current_password || !$new_password || !$confirm_password) {
        flash_set('error', 'All password fields are required.');
        redirect('/admin/change_password.php');
    }

    if (!password_verify($current_password, $user['password_hash'])) {
        flash_set('error', 'Current password is incorrect.');
        redirect('/admin/change_password.php');
    }

    if (strlen($new_password) < 8) {
        flash_set('error', 'New password must be at least 8 characters.');
        redirect('/admin/change_password.php');
    }

    if ($new_password !== $confirm_password) {
        flash_set('error', 'New passwords do not match.');
        redirect('/admin/change_password.php');
    }

    $hash = password_hash($new_password, PASSWORD_BCRYPT, ['cost' => 12]);
    db_query('UPDATE admins SET password_hash = ? WHERE id = ?', [$hash, $_SESSION['admin_id']]);

    flash_set('success', 'Password changed successfully.');
    redirect('/admin/change_password.php');
}

include __DIR__ . '/../includes/header.php';
?>

<div class="page-actions">
  <h2>Change Password</h2>
  <a href="<?= APP_URL ?>/admin/dashboard.php" class="btn btn--outline">Back to Dashboard</a>
</div>

<div class="card" style="max-width:620px;">
  <div class="card__title">Account Security</div>
  <form method="POST" action="">
    <?= csrf_field() ?>
    <div class="form-group">
      <label class="form-label">Current Password</label>
      <input type="password" name="current_password" class="form-control" required autofocus>
    </div>
    <div class="form-group">
      <label class="form-label">New Password</label>
      <input type="password" name="new_password" class="form-control" minlength="8" required>
      <span class="form-hint">Use at least 8 characters.</span>
    </div>
    <div class="form-group">
      <label class="form-label">Confirm New Password</label>
      <input type="password" name="confirm_password" class="form-control" minlength="8" required>
    </div>
    <button type="submit" class="btn btn--primary">Update Password</button>
  </form>
</div>

<?php include __DIR__ . '/../includes/footer.php'; ?>

<?php
require_once __DIR__ . '/../includes/helpers.php';
require_login();
$page_title = 'Responses';

// Get all admin's surveys for filter
$admin_surveys = db_fetch_all(
    'SELECT id, title FROM surveys WHERE admin_id = ? ORDER BY title',
    [$_SESSION['admin_id']]
);

$survey_id = (int)($_GET['survey_id'] ?? 0);
$per_page  = 20;
$page      = max(1, (int)($_GET['page'] ?? 1));

$rows = [];
$pager = null;

if ($survey_id) {
    // Verify ownership
    $survey = db_fetch('SELECT * FROM surveys WHERE id = ? AND admin_id = ?', [$survey_id, $_SESSION['admin_id']]);
    if (!$survey) { flash_set('error', 'Survey not found.'); redirect('/admin/responses.php'); }

    $total = (int) db_fetch(
        'SELECT COUNT(*) AS c FROM response_sessions WHERE survey_id = ?', [$survey_id]
    )['c'];

    $pager = paginate($total, $per_page, $page);

    $rows = db_fetch_all(
        'SELECT rs.*, s.title AS survey_title
         FROM response_sessions rs
         JOIN surveys s ON rs.survey_id = s.id
         WHERE rs.survey_id = ?
         ORDER BY rs.submitted_at DESC
         LIMIT ? OFFSET ?',
        [$survey_id, $per_page, $pager['offset']]
    );
}

include __DIR__ . '/../includes/header.php';
?>

<div class="page-actions">
  <h2>Response Log</h2>
  <?php if ($survey_id): ?>
    <a href="<?= APP_URL ?>/admin/export.php?survey_id=<?= $survey_id ?>" class="btn btn--gold btn--sm">⬇ Export CSV</a>
    <a href="<?= APP_URL ?>/admin/analytics.php?survey_id=<?= $survey_id ?>" class="btn btn--outline btn--sm">📊 Analytics</a>
  <?php endif; ?>
</div>

<div class="filter-bar">
  <form method="GET">
    <select name="survey_id" onchange="this.form.submit()" class="form-control">
      <option value="">— Select a Survey —</option>
      <?php foreach ($admin_surveys as $sv): ?>
        <option value="<?= $sv['id'] ?>" <?= $survey_id === (int)$sv['id'] ? 'selected' : '' ?>>
          <?= h($sv['title']) ?>
        </option>
      <?php endforeach; ?>
    </select>
  </form>
</div>

<?php if (!$survey_id): ?>
  <div class="card text-center" style="padding:48px;">
    <p class="text-muted">Select a survey above to view its responses.</p>
  </div>
<?php elseif (empty($rows)): ?>
  <div class="card text-center" style="padding:48px;">
    <p class="text-muted">No responses yet for <strong><?= h($survey['title']) ?></strong>.</p>
  </div>
<?php else: ?>
  <p class="text-muted" style="margin-bottom:12px;font-size:.85rem;">
    <?= number_format($pager['total']) ?> total responses for <strong><?= h($survey['title']) ?></strong>
  </p>

  <?php foreach ($rows as $session): ?>
  <div class="card" style="margin-bottom:14px;">
    <div style="display:flex;align-items:flex-start;gap:14px;flex-wrap:wrap;">
      <div style="flex:1;min-width:180px;">
        <div style="font-size:.78rem;color:var(--muted);font-weight:700;text-transform:uppercase;letter-spacing:.05em;">Submitted</div>
        <div style="font-weight:600;margin-top:2px;"><?= date('d M Y, H:i', strtotime($session['submitted_at'])) ?></div>
      </div>
      <?php if (!$survey['is_anonymous']): ?>
      <div style="flex:1;min-width:150px;">
        <div style="font-size:.78rem;color:var(--muted);font-weight:700;text-transform:uppercase;letter-spacing:.05em;">Respondent</div>
        <div class="response-meta-value"><?= h($session['respondent_name'] ?: 'Anonymous') ?></div>
        <div class="response-meta-email"><?= h($session['respondent_email'] ?? '') ?></div>
      </div>
      <?php endif; ?>
      <div style="flex:1;min-width:120px;">
        <div style="font-size:.78rem;color:var(--muted);font-weight:700;text-transform:uppercase;letter-spacing:.05em;">IP Address</div>
        <div class="response-meta-ip"><?= h($session['ip_address'] ?? '—') ?></div>
      </div>
    </div>

    <?php
    $answers = db_fetch_all(
        'SELECT a.answer_value, q.question_text, q.question_type
         FROM answers a
         JOIN questions q ON a.question_id = q.id
         WHERE a.session_id = ?
         ORDER BY q.sort_order, q.id',
        [$session['id']]
    );
    ?>
    <?php if (!empty($answers)): ?>
    <div style="margin-top:14px;padding-top:14px;border-top:1px solid var(--border);">
      <?php foreach ($answers as $ai => $ans): ?>
        <div style="margin-bottom:10px;">
          <div style="font-size:.8rem;font-weight:700;color:var(--muted);">Q<?= $ai+1 ?>. <?= h($ans['question_text']) ?></div>
          <div style="margin-top:3px;font-size:.9rem;">
            <?php if ($ans['question_type'] === 'rating'): ?>
              <span style="background:var(--green);color:#fff;border-radius:6px;padding:2px 10px;font-weight:700;"><?= h($ans['answer_value']) ?>/10</span>
            <?php else: ?>
              <?= h($ans['answer_value']) ?>
            <?php endif; ?>
          </div>
        </div>
      <?php endforeach; ?>
    </div>
    <?php endif; ?>
  </div>
  <?php endforeach; ?>

  <!-- Pagination -->
  <?php if ($pager['total_pages'] > 1): ?>
  <div style="display:flex;justify-content:center;gap:6px;padding:10px 0 20px;">
    <?php for ($p = 1; $p <= $pager['total_pages']; $p++):
        $q = http_build_query(['survey_id' => $survey_id, 'page' => $p]);
    ?>
      <a href="?<?= $q ?>" class="btn btn--outline btn--sm <?= $p === $pager['current'] ? 'btn--primary' : '' ?>"><?= $p ?></a>
    <?php endfor; ?>
  </div>
  <?php endif; ?>
<?php endif; ?>

<?php include __DIR__ . '/../includes/footer.php'; ?>

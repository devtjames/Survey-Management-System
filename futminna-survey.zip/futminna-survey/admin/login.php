<?php
require_once __DIR__ . '/../includes/helpers.php';
session_start_safe();

if (is_logged_in()) redirect('/admin/dashboard.php');

$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrf_protect();
    $email    = strtolower(sanitize($_POST['email'] ?? ''));
    $password = $_POST['password'] ?? '';

    if (!$email || !$password) {
        $error = 'Email and password are required.';
    } else {
        $admin = db_fetch('SELECT * FROM admins WHERE email = ?', [$email]);
        if ($admin && password_verify($password, $admin['password_hash'])) {
            session_regenerate_id(true);
            $_SESSION['admin_id']   = $admin['id'];
            $_SESSION['user_id']    = $admin['id'];
            $_SESSION['admin_name'] = $admin['name'];
            redirect('/admin/dashboard.php');
        } else {
            $error = 'Invalid credentials. Please try again.';
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Login — FUTMINNA Survey System</title>
<link rel="preconnect" href="https://fonts.googleapis.com">
<link href="https://fonts.googleapis.com/css2?family=DM+Serif+Display:ital@0;1&family=Sora:wght@300;400;500;600;700&display=swap" rel="stylesheet">
<link rel="stylesheet" href="<?= APP_URL ?>/assets/css/admin.css">
</head>
<body class="login-page">
<div class="login-box">
  <div class="login-box__logo">◈</div>
  <h1 class="login-box__title">FUTMINNA</h1>
  <p class="login-box__sub">Sign in to create and manage your surveys</p>

  <?php if ($error): ?>
    <div class="alert alert--error"><?= h($error) ?></div>
  <?php endif; ?>

  <form method="POST" action="">
    <?= csrf_field() ?>
    <div class="form-group">
      <label class="form-label">Email Address</label>
      <input type="email" name="email" class="form-control"
             value="<?= h($_POST['email'] ?? '') ?>"
             placeholder="you@example.com" required autofocus>
    </div>
    <div class="form-group">
      <label class="form-label">Password</label>
      <input type="password" name="password" class="form-control" placeholder="••••••••" required>
    </div>
    <button type="submit" class="btn btn--primary" style="width:100%;justify-content:center;padding:12px;">
      Sign In
    </button>
  </form>

  <p style="text-align:center;margin-top:18px;font-size:.82rem;color:var(--muted);">
    New here?
    <a href="<?= APP_URL ?>/admin/register.php" style="font-weight:700;color:var(--green);">Create an account</a>
  </p>
</div>
</body>
</html>

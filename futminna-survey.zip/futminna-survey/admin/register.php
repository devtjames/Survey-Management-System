<?php
require_once __DIR__ . '/../includes/helpers.php';
session_start_safe();

if (is_logged_in()) redirect('/admin/dashboard.php');

$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrf_protect();

    $name             = post('name');
    $email            = strtolower(post('email'));
    $password         = $_POST['password'] ?? '';
    $confirm_password = $_POST['confirm_password'] ?? '';

    if (!$name || !$email || !$password || !$confirm_password) {
        $error = 'All fields are required.';
    } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $error = 'Enter a valid email address.';
    } elseif (strlen($password) < 8) {
        $error = 'Password must be at least 8 characters.';
    } elseif ($password !== $confirm_password) {
        $error = 'Passwords do not match.';
    } elseif (db_fetch('SELECT id FROM admins WHERE email = ?', [$email])) {
        $error = 'An account with this email already exists.';
    } else {
        $password_hash = password_hash($password, PASSWORD_BCRYPT, ['cost' => 12]);

        try {
            $user_id = db_insert(
                'INSERT INTO admins (name, email, password_hash) VALUES (?,?,?)',
                [$name, $email, $password_hash]
            );

            session_regenerate_id(true);
            $_SESSION['admin_id']   = $user_id;
            $_SESSION['user_id']    = $user_id;
            $_SESSION['admin_name'] = $name;
            flash_set('success', 'Welcome! Your account has been created.');
            redirect('/admin/dashboard.php');
        } catch (PDOException $e) {
            $error = 'Unable to create account right now. Please try again.';
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Create Account — FUTMINNA Survey System</title>
<link rel="preconnect" href="https://fonts.googleapis.com">
<link href="https://fonts.googleapis.com/css2?family=DM+Serif+Display:ital@0;1&family=Sora:wght@300;400;500;600;700&display=swap" rel="stylesheet">
<link rel="stylesheet" href="<?= APP_URL ?>/assets/css/admin.css">
</head>
<body class="login-page">
<div class="login-box">
  <div class="login-box__logo">◈</div>
  <h1 class="login-box__title">Create Account</h1>
  <p class="login-box__sub">Register to create and manage your own surveys</p>

  <?php if ($error): ?>
    <div class="alert alert--error"><?= h($error) ?></div>
  <?php endif; ?>

  <form method="POST" action="">
    <?= csrf_field() ?>
    <div class="form-group">
      <label class="form-label">Full Name</label>
      <input type="text" name="name" class="form-control"
             value="<?= h($_POST['name'] ?? '') ?>"
             placeholder="Your name" required autofocus>
    </div>
    <div class="form-group">
      <label class="form-label">Email Address</label>
      <input type="email" name="email" class="form-control"
             value="<?= h($_POST['email'] ?? '') ?>"
             placeholder="you@example.com" required>
    </div>
    <div class="form-group">
      <label class="form-label">Password</label>
      <input type="password" name="password" class="form-control" placeholder="At least 8 characters" required>
    </div>
    <div class="form-group">
      <label class="form-label">Confirm Password</label>
      <input type="password" name="confirm_password" class="form-control" placeholder="Repeat your password" required>
    </div>
    <button type="submit" class="btn btn--primary" style="width:100%;justify-content:center;padding:12px;">
      Create Account
    </button>
  </form>

  <p style="text-align:center;margin-top:18px;font-size:.82rem;color:var(--muted);">
    Already have an account?
    <a href="<?= APP_URL ?>/admin/login.php" style="font-weight:700;color:var(--green);">Sign in</a>
  </p>
</div>
</body>
</html>

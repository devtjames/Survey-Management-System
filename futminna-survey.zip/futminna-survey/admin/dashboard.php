<?php
require_once __DIR__ . '/../includes/helpers.php';
require_login();

$page_title = 'Dashboard';

// Stats
$total_surveys   = db_fetch('SELECT COUNT(*) AS c FROM surveys WHERE admin_id = ?', [$_SESSION['admin_id']])['c'];
$active_surveys  = db_fetch('SELECT COUNT(*) AS c FROM surveys WHERE admin_id = ? AND status = "active"', [$_SESSION['admin_id']])['c'];
$total_responses = db_fetch('SELECT COUNT(*) AS c FROM response_sessions rs JOIN surveys s ON rs.survey_id = s.id WHERE s.admin_id = ?', [$_SESSION['admin_id']])['c'];
$total_questions = db_fetch('SELECT COUNT(*) AS c FROM questions q JOIN surveys s ON q.survey_id = s.id WHERE s.admin_id = ?', [$_SESSION['admin_id']])['c'];

// Responses per day last 7 days
$resp_trend = db_fetch_all(
    'SELECT DATE(rs.submitted_at) AS day, COUNT(*) AS cnt
     FROM response_sessions rs
     JOIN surveys s ON rs.survey_id = s.id
     WHERE s.admin_id = ? AND rs.submitted_at >= DATE_SUB(NOW(), INTERVAL 7 DAY)
     GROUP BY day ORDER BY day',
    [$_SESSION['admin_id']]
);
$trend_labels = [];
$trend_values = [];
// Fill all 7 days
for ($i = 6; $i >= 0; $i--) {
    $day = date('Y-m-d', strtotime("-{$i} days"));
    $trend_labels[] = date('D d', strtotime($day));
    $found = array_filter($resp_trend, fn($r) => $r['day'] === $day);
    $trend_values[] = $found ? array_values($found)[0]['cnt'] : 0;
}

// Survey status breakdown
$status_counts = db_fetch_all(
    'SELECT status, COUNT(*) AS cnt FROM surveys WHERE admin_id = ? GROUP BY status',
    [$_SESSION['admin_id']]
);
$status_map = ['active' => 0, 'draft' => 0, 'closed' => 0];
foreach ($status_counts as $row) $status_map[$row['status']] = $row['cnt'];

// Recent surveys
$recent = db_fetch_all(
    'SELECT s.*, (SELECT COUNT(*) FROM response_sessions r WHERE r.survey_id = s.id) AS resp_count
     FROM surveys s WHERE admin_id = ? ORDER BY created_at DESC LIMIT 5',
    [$_SESSION['admin_id']]
);

$extra_js = '<script src="https://cdn.jsdelivr.net/npm/chart.js@4/dist/chart.umd.min.js"></script>
<script>
const rData = ' . json_encode(['labels' => $trend_labels, 'values' => $trend_values]) . ';
const sData = ' . json_encode(['labels' => ['Active','Draft','Closed'], 'values' => array_values($status_map)]) . ';
document.addEventListener("DOMContentLoaded", () => initDashboardCharts(rData, sData));
</script>';

include __DIR__ . '/../includes/header.php';
?>

<div class="stats-grid">
  <div class="stat-card">
    <div class="stat-card__label">Total Surveys</div>
    <div class="stat-card__value"><?= $total_surveys ?></div>
    <div class="stat-card__sub">All time</div>
  </div>
  <div class="stat-card stat-card--gold">
    <div class="stat-card__label">Active Surveys</div>
    <div class="stat-card__value"><?= $active_surveys ?></div>
    <div class="stat-card__sub">Currently live</div>
  </div>
  <div class="stat-card stat-card--blue">
    <div class="stat-card__label">Total Responses</div>
    <div class="stat-card__value"><?= number_format($total_responses) ?></div>
    <div class="stat-card__sub">Across all surveys</div>
  </div>
  <div class="stat-card stat-card--red">
    <div class="stat-card__label">Questions Created</div>
    <div class="stat-card__value"><?= $total_questions ?></div>
    <div class="stat-card__sub">MCQ, Text, Rating</div>
  </div>
</div>

<div class="chart-grid">
  <div class="chart-box">
    <div class="chart-box__title">📊 Responses — Last 7 Days</div>
    <canvas id="chart-responses"></canvas>
  </div>
  <div class="chart-box">
    <div class="chart-box__title">🗂 Survey Status Distribution</div>
    <canvas id="chart-status"></canvas>
  </div>
</div>

<div class="card">
  <div class="card__title">Recent Surveys</div>
  <?php if (empty($recent)): ?>
    <p class="text-muted text-center" style="padding:24px;">No surveys yet. <a href="<?= APP_URL ?>/admin/survey_create.php" class="btn btn--primary btn--sm" style="margin-left:8px;">Create First Survey</a></p>
  <?php else: ?>
    <div class="table-wrap table-wrap--recent-surveys">
      <table class="responsive-table responsive-table--recent-surveys">
        <thead><tr><th>Title</th><th>Status</th><th>Responses</th><th>Expires</th><th>Created</th><th></th></tr></thead>
        <tbody>
        <?php foreach ($recent as $s): ?>
          <?php $expired = survey_is_expired($s); ?>
          <tr>
            <td><strong><?= h($s['title']) ?></strong></td>
            <td>
              <?php if ($expired): ?>
                <span class="badge badge--expired">Expired</span>
              <?php else: ?>
                <span class="badge badge--<?= h($s['status']) ?>"><?= h($s['status']) ?></span>
              <?php endif; ?>
            </td>
            <td><?= $s['resp_count'] ?></td>
            <td><?= $s['expires_at'] ? date('d M Y', strtotime($s['expires_at'])) : '—' ?></td>
            <td><?= date('d M Y', strtotime($s['created_at'])) ?></td>
            <td><a href="<?= APP_URL ?>/admin/survey_edit.php?id=<?= $s['id'] ?>" class="btn btn--outline btn--xs">Edit</a></td>
          </tr>
        <?php endforeach; ?>
        </tbody>
      </table>
    </div>
    <div style="margin-top:14px;">
      <a href="<?= APP_URL ?>/admin/surveys.php" class="btn btn--outline btn--sm">View All Surveys →</a>
    </div>
  <?php endif; ?>
</div>

<?php include __DIR__ . '/../includes/footer.php'; ?>

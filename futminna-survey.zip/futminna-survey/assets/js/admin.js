// assets/js/admin.js — FUTMINNA Survey System

/* ═══════════════════════════════════════════════════════════════════
   CSRF TOKEN (read from meta or hidden input in page)
═══════════════════════════════════════════════════════════════════ */
function getCsrfToken() {
  const el = document.getElementById('csrf_token') ||
             document.querySelector('[name="csrf_token"]');
  return el ? el.value : '';
}

/* ═══════════════════════════════════════════════════════════════════
   AJAX HELPER
═══════════════════════════════════════════════════════════════════ */
async function apiPost(url, data = {}) {
  data['csrf_token'] = getCsrfToken();
  const body = new URLSearchParams(data);
  const res = await fetch(url, {
    method: 'POST',
    headers: { 'Content-Type': 'application/x-www-form-urlencoded',
                'X-Csrf-Token': getCsrfToken() },
    body
  });
  return res.json();
}

/* ═══════════════════════════════════════════════════════════════════
   FLASH NOTIFICATION (client-side)
═══════════════════════════════════════════════════════════════════ */
function showToast(msg, type = 'success') {
  let container = document.getElementById('toast-container');
  if (!container) {
    container = document.createElement('div');
    container.id = 'toast-container';
    container.style.cssText = 'position:fixed;top:20px;right:20px;z-index:9999;display:flex;flex-direction:column;gap:8px;';
    document.body.appendChild(container);
  }
  const t = document.createElement('div');
  t.className = `alert alert--${type}`;
  t.style.cssText = 'min-width:240px;max-width:360px;animation:slideIn .2s ease;box-shadow:0 4px 20px rgba(0,0,0,.15)';
  t.textContent = msg;
  container.appendChild(t);
  setTimeout(() => { t.style.opacity='0'; t.style.transition='opacity .3s'; setTimeout(() => t.remove(), 300); }, 3500);
}

/* ═══════════════════════════════════════════════════════════════════
   CONFIRM DIALOG
═══════════════════════════════════════════════════════════════════ */
function confirmAction(msg, callback) {
  if (window.confirm(msg)) callback();
}

/* ═══════════════════════════════════════════════════════════════════
   SURVEY DELETE
═══════════════════════════════════════════════════════════════════ */
document.addEventListener('click', async (e) => {
  const btn = e.target.closest('[data-delete-survey]');
  if (!btn) return;
  const id = btn.dataset.deleteSurvey;
  confirmAction('Delete this survey? This cannot be undone.', async () => {
    btn.disabled = true;
    const res = await apiPost('ajax/delete_survey.php', { id });
    if (res.success) {
      const row = document.getElementById(`survey-row-${id}`);
      if (row) { row.style.opacity = 0; setTimeout(() => row.remove(), 300); }
      showToast('Survey deleted.');
    } else {
      showToast(res.error || 'Delete failed.', 'error');
      btn.disabled = false;
    }
  });
});

/* ═══════════════════════════════════════════════════════════════════
   STATUS TOGGLE
═══════════════════════════════════════════════════════════════════ */
document.addEventListener('change', async (e) => {
  const sel = e.target.closest('[data-status-survey]');
  if (!sel) return;
  const id = sel.dataset.statusSurvey;
  const status = sel.value;
  const res = await apiPost('ajax/update_status.php', { id, status });
  if (res.success) showToast('Status updated.');
  else showToast(res.error || 'Update failed.', 'error');
});

/* ═══════════════════════════════════════════════════════════════════
   COPY SURVEY LINK
═══════════════════════════════════════════════════════════════════ */
document.addEventListener('click', (e) => {
  const btn = e.target.closest('[data-copy-link]');
  if (!btn) return;
  const url = btn.dataset.copyLink;
  navigator.clipboard.writeText(url).then(() => showToast('Link copied to clipboard!'));
});

/* ═══════════════════════════════════════════════════════════════════
   QUESTION BUILDER
═══════════════════════════════════════════════════════════════════ */
(function () {
  const builder = document.getElementById('question-builder');
  if (!builder) return;

  let qCount = parseInt(builder.dataset.startCount || '0');

  function makeQuestion(type) {
    qCount++;
    const n = qCount;
    const div = document.createElement('div');
    div.className = 'question-item';
    div.dataset.qn = n;
    div.innerHTML = `
      <button type="button" class="remove-btn" onclick="this.closest('.question-item').remove(); renumber();">✕</button>
      <div class="question-item__header">
        <div class="question-item__num">${n}</div>
        <input type="hidden" name="q_type[]" value="${type}">
        <span class="q-type-label">${type.toUpperCase()}</span>
      </div>
      <div class="form-group mb-0">
        <input type="text" name="q_text[]" class="form-control" placeholder="Question text…" required>
      </div>
      <div class="form-row mt-1" style="grid-template-columns:auto 1fr; align-items:center; margin-top:8px;">
        <label style="display:flex;align-items:center;gap:6px;font-size:.8rem;color:var(--muted);">
          <input type="checkbox" name="q_required_${n}" value="1" checked> Required
        </label>
        <input type="hidden" name="q_required[]" value="0" class="required-hidden-${n}">
      </div>
      ${type === 'mcq' ? buildMcqOptions(n) : ''}
      ${type === 'rating' ? '<p class="form-hint mt-1">Respondents will rate 1–10.</p>' : ''}
    `;
    // Sync required checkbox to hidden input
    const cb  = div.querySelector(`[name="q_required_${n}"]`);
    const hid = div.querySelector(`.required-hidden-${n}`);
    cb.addEventListener('change', () => hid.value = cb.checked ? '1' : '0');
    hid.value = '1';
    return div;
  }

  function buildMcqOptions(n) {
    return `
      <div class="mcq-options" id="mcq-opts-${n}">
        <div class="form-hint mb-0" style="margin:8px 0 6px;">Options:</div>
        <div class="mcq-option">
          <input type="text" name="q_options[${n}][]" class="form-control" placeholder="Option 1" required>
          <button type="button" class="btn btn--outline btn--xs" onclick="addMcqOpt(${n})">+ Add</button>
        </div>
        <div class="mcq-option">
          <input type="text" name="q_options[${n}][]" class="form-control" placeholder="Option 2">
          <button type="button" class="btn btn--danger btn--xs" onclick="this.closest('.mcq-option').remove()">✕</button>
        </div>
      </div>`;
  }

  window.addMcqOpt = function(n) {
    const container = document.getElementById(`mcq-opts-${n}`);
    const div = document.createElement('div');
    div.className = 'mcq-option';
    div.innerHTML = `<input type="text" name="q_options[${n}][]" class="form-control" placeholder="Option…">
                     <button type="button" class="btn btn--danger btn--xs" onclick="this.closest('.mcq-option').remove()">✕</button>`;
    container.appendChild(div);
    div.querySelector('input').focus();
  };

  window.renumber = function() {
    document.querySelectorAll('#question-builder .question-item').forEach((item, i) => {
      const num = item.querySelector('.question-item__num');
      if (num) num.textContent = i + 1;
    });
  };

  // Add buttons
  document.getElementById('add-mcq')?.addEventListener('click', () => {
    builder.appendChild(makeQuestion('mcq'));
  });
  document.getElementById('add-text')?.addEventListener('click', () => {
    builder.appendChild(makeQuestion('text'));
  });
  document.getElementById('add-rating')?.addEventListener('click', () => {
    builder.appendChild(makeQuestion('rating'));
  });
})();

/* ═══════════════════════════════════════════════════════════════════
   RATING BUTTONS (survey public page)
═══════════════════════════════════════════════════════════════════ */
document.addEventListener('click', (e) => {
  const btn = e.target.closest('.rating-btn');
  if (!btn) return;
  const wrap = btn.closest('.rating-wrap');
  if (!wrap) return;
  wrap.querySelectorAll('.rating-btn').forEach(b => b.classList.remove('selected'));
  btn.classList.add('selected');
  const hidden = wrap.nextElementSibling;
  if (hidden && hidden.type === 'hidden') hidden.value = btn.dataset.val;
});

/* ═══════════════════════════════════════════════════════════════════
   PUBLIC SURVEY AJAX SUBMISSION
═══════════════════════════════════════════════════════════════════ */
(function () {
  const form = document.getElementById('survey-form');
  if (!form) return;

  form.addEventListener('submit', async (e) => {
    e.preventDefault();
    const btn = form.querySelector('[type="submit"]');
    const origText = btn.innerHTML;
    btn.innerHTML = '<span class="spinner"></span> Submitting…';
    btn.disabled = true;

    const data = {};
    new FormData(form).forEach((val, key) => {
      // Handle multiple checkboxes with same name
      if (data[key] !== undefined) {
        if (!Array.isArray(data[key])) data[key] = [data[key]];
        data[key].push(val);
      } else {
        data[key] = val;
      }
    });

    // Convert arrays to JSON strings for transport
    const postData = {};
    for (const [k, v] of Object.entries(data)) {
      postData[k] = Array.isArray(v) ? JSON.stringify(v) : v;
    }

    try {
      const res = await apiPost(form.action, postData);
      if (res.success) {
        form.closest('.survey-body').innerHTML = `
          <div style="text-align:center;padding:48px 24px;">
            <div style="font-size:3rem;margin-bottom:16px;">✅</div>
            <h2 style="font-family:var(--font-display);font-size:1.8rem;color:var(--green-dk);margin-bottom:10px;">Thank you!</h2>
            <p style="color:var(--muted);">${res.message || 'Your response has been recorded.'}</p>
          </div>`;
      } else {
        showToast(res.error || 'Submission failed. Please try again.', 'error');
        btn.innerHTML = origText;
        btn.disabled = false;
      }
    } catch (err) {
      showToast('Network error. Please check your connection.', 'error');
      btn.innerHTML = origText;
      btn.disabled = false;
    }
  });
})();

/* ═══════════════════════════════════════════════════════════════════
   DASHBOARD CHARTS (Chart.js)
═══════════════════════════════════════════════════════════════════ */
window.initDashboardCharts = function(responseData, surveyData) {
  const GREEN  = '#006B3F';
  const GOLD   = '#D4A017';
  const COLORS = [GREEN,'#1a9f6a',GOLD,'#2980b9','#8e44ad','#c0392b','#16a085','#d35400'];

  const defaults = {
    responsive: true,
    maintainAspectRatio: true,
    plugins: { legend: { labels: { font: { family: "'Sora', sans-serif", size: 12 } } } }
  };

  const responsesCtx = document.getElementById('chart-responses');
  if (responsesCtx && responseData) {
    new Chart(responsesCtx, {
      type: 'bar',
      data: {
        labels: responseData.labels,
        datasets: [{
          label: 'Responses',
          data: responseData.values,
          backgroundColor: GREEN,
          borderRadius: 6,
        }]
      },
      options: {
        ...defaults,
        scales: {
          y: { beginAtZero: true, ticks: { stepSize: 1 } },
          x: { grid: { display: false } }
        }
      }
    });
  }

  const statusCtx = document.getElementById('chart-status');
  if (statusCtx && surveyData) {
    new Chart(statusCtx, {
      type: 'doughnut',
      data: {
        labels: surveyData.labels,
        datasets: [{ data: surveyData.values, backgroundColor: [GREEN, GOLD, '#ccc'], borderWidth: 0 }]
      },
      options: {
        ...defaults,
        cutout: '65%',
        plugins: { ...defaults.plugins, tooltip: { callbacks: { label: (c) => ` ${c.label}: ${c.raw}` } } }
      }
    });
  }
};

window.initAnalyticsChart = function(canvasId, type, labels, datasets) {
  const ctx = document.getElementById(canvasId);
  if (!ctx) return;
  const colors = ['#006B3F','#D4A017','#2980b9','#8e44ad','#c0392b','#16a085'];
  new Chart(ctx, {
    type,
    data: {
      labels,
      datasets: datasets.map((d, i) => ({
        label: d.label,
        data: d.data,
        backgroundColor: type === 'bar' ? colors[i % colors.length] : colors.slice(0, d.data.length),
        borderColor: type === 'line' ? colors[i % colors.length] : undefined,
        borderWidth: type === 'line' ? 2 : 0,
        fill: type === 'line' ? false : undefined,
        borderRadius: type === 'bar' ? 5 : undefined,
      }))
    },
    options: {
      responsive: true,
      maintainAspectRatio: true,
      plugins: { legend: { labels: { font: { family: "'Sora', sans-serif" } } } },
      scales: type !== 'pie' && type !== 'doughnut' ? { y: { beginAtZero: true } } : undefined
    }
  });
};

/* sidebar overlay close */
document.addEventListener('click', (e) => {
  if (window.innerWidth <= 768 &&
      !e.target.closest('.sidebar') &&
      !e.target.closest('.topbar__toggle') &&
      document.body.classList.contains('sidebar-open')) {
    document.body.classList.remove('sidebar-open');
  }
});

const style = document.createElement('style');
style.textContent = `@keyframes slideIn{from{transform:translateX(40px);opacity:0}to{transform:translateX(0);opacity:1}}`;
document.head.appendChild(style);

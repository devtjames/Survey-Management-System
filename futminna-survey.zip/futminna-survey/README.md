# FUTMINNA Survey Management System

A full-featured, secure survey management system built with procedural PHP, PDO MySQL, and vanilla JavaScript.

---

## Requirements

- PHP 8.1+
- MySQL 8.0+ (or MariaDB 10.6+)
- Apache with `mod_rewrite` enabled
- Composer (not required — no dependencies)

---

## Installation

### 1. Database Setup

```bash
mysql -u root -p < schema.sql
```

This creates the `futminna_surveys` database and seeds a default starter account. New users can also self-register from the login page.

**Default credentials:**
- Email: `admin@futminna.edu.ng`
- Password: `password`

> Change the starter password immediately after first login via the Change Password page.

### 2. Configure Database

Edit `config/config.php`:

```php
define('DB_HOST', 'localhost');
define('DB_NAME', 'futminna_surveys');
define('DB_USER', 'your_db_user');
define('DB_PASS', 'your_db_password');
```

Also update `APP_URL` to match your server:

```php
define('APP_URL', 'http://localhost/futminna-survey');
```

### 3. Web Server

**Apache (recommended):**

Place the project in your web root (e.g. `/var/www/html/futminna-survey/` or `htdocs/futminna-survey/`).

Enable `mod_rewrite`:
```bash
sudo a2enmod rewrite headers
sudo systemctl restart apache2
```

Ensure `AllowOverride All` in your Apache virtual host.

**XAMPP/WAMP users:**  
Drop the folder in `htdocs/` and access via `http://localhost/futminna-survey/`.

### 4. File Permissions

```bash
chmod 755 exports/
chmod 644 config/config.php
```

---

## Folder Structure

```
futminna-survey/
├── config/
│   └── config.php          # DB credentials, app constants
├── includes/
│   ├── db.php              # PDO singleton + query helpers
│   ├── helpers.php         # CSRF, session, flash, sanitize, redirect
│   ├── header.php          # Admin layout header
│   └── footer.php          # Admin layout footer
├── admin/
│   ├── login.php           # User authentication
│   ├── register.php        # Public user registration
│   ├── change_password.php # Change logged-in user's password
│   ├── logout.php          # Session destroy
│   ├── dashboard.php       # Stats + charts overview
│   ├── surveys.php         # Survey list with AJAX delete/status
│   ├── survey_create.php   # Create survey + dynamic question builder
│   ├── survey_edit.php     # Edit survey + questions
│   ├── responses.php       # Browse all responses
│   ├── analytics.php       # Per-question charts & statistics
│   ├── export.php          # CSV export
│   └── ajax/
│       ├── delete_survey.php   # POST: delete survey
│       └── update_status.php   # POST: change status
├── public/
│   ├── survey.php          # Public-facing survey form
│   └── submit.php          # AJAX response submission
├── assets/
│   ├── css/admin.css       # Full UI stylesheet
│   └── js/admin.js         # AJAX, question builder, charts
├── exports/                # (empty, for future local export storage)
├── schema.sql              # Database schema + seed
├── .htaccess               # Security rules
└── index.php               # Redirect to login
```

---

## Features

| Feature | Details |
|---|---|
| Authentication | Public registration/login, session-based, password_hash bcrypt, CSRF protected |
| User isolation | Each survey belongs to the user who created it; dashboards, responses, analytics, exports, editing, status changes, and deletes are owner-scoped |
| Survey types | Anonymous or identified respondents |
| Question types | MCQ (multi-choice), Text, Rating (1–10) |
| Expiration | Optional date/time expiry per survey |
| AJAX submission | Zero page reload on public survey form |
| Analytics | Pie charts (MCQ), bar distributions (Rating), text samples |
| Dashboard | 7-day response trend, status donut, recent surveys |
| Export | UTF-8 BOM CSV for Excel compatibility |
| Security | PDO prepared statements, CSRF tokens, XSS escaping, input sanitization |

---

## Security Notes

- All DB queries use PDO prepared statements — no raw interpolation
- CSRF tokens are validated on every POST request
- Passwords stored with `PASSWORD_BCRYPT` (cost=12)
- `htmlspecialchars()` on all rendered user data
- `.htaccess` blocks direct access to `includes/` and `config/`
- Set `DEBUG_MODE = false` in production

---

## Account Management

Use the public registration link on the login page to create user accounts. Logged-in users can update their password from **Change Password** in the sidebar.

---

## Built With

- PHP 8.1+ (procedural, no framework)
- MySQL 8.0+ via PDO
- HTML5 / CSS3 / Vanilla JavaScript (ES2020)
- Chart.js 4.x (CDN)
- Google Fonts: DM Serif Display + Sora

---

**Federal University of Technology, Minna (FUTMINNA)**  
Survey Management System v1.0
